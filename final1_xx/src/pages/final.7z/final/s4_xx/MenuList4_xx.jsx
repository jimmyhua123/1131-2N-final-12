const MenuList4_xx = () => {
  return (
    <div className='section-center'>
      <h1>MenuList4_xx</h1>
    </div>
  );
};
export default MenuList4_xx;
