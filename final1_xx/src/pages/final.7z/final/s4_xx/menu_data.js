const menu = [
  {
    id: 1,
    title: 'buttermilk pancakes',
    category: 'breakfast',
    price: 15.59,
    img: '/item-1.jpeg',
    remote_img: '',
    descrip:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimos ullam. E',
  },
  {
    id: 2,
    title: 'diner double',
    category: 'dessert',
    price: 13.99,
    img: '/item-2.jpeg',
    remote_img: '',
    descrip:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimos ullam. Enim voluptas, expedita ',
  },
  {
    id: 3,
    title: 'godzilla milkshake',
    category: 'shakes',
    price: 6.99,
    img: '/item-3.jpeg',
    remote_img: '',
    descrip:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimos ullam. ',
  },
  {
    id: 4,
    title: 'Country Delight',
    category: 'lunch',
    price: 20.99,
    img: '/item-4.jpeg',
    remote_img: '',
    descrip:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimos ',
  },
  {
    id: 5,
    title: 'Egg Attack',
    category: 'breakfast',
    price: 2.99,
    img: '/item-5.jpeg',
    remote_img: '',
    descrip:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissim',
  },
  {
    id: 6,
    title: 'Oreo Dream',
    category: 'shakes',
    price: 18.99,
    img: '/item-6.jpeg',
    remote_img: '',
    descrip:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto ',
  },
  {
    id: 7,
    title: 'Bacon Overflow',
    category: 'breakfast',
    price: 8.99,
    img: '/item-7.jpeg',
    remote_img: '',
    descrip:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimo',
  },
  {
    id: 8,
    title: 'American Classic',
    category: 'lunch',
    price: 12.99,
    img: '/item-8.jpeg',
    remote_img: '',
    descrip:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas quia dignissimos',
  },
  {
    id: 9,
    title: 'Quarantine Buddy',
    category: 'shakes',
    price: 13.99,
    img: '/item-9.jpeg',
    remote_img: '',
    descrip:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam dolores ut iusto quas qu',
  },
];

export default menu;
