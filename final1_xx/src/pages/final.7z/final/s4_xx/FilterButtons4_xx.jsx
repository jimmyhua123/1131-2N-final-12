import { useMenuContext_xx } from './contextMenu_xx';

const FilterButtons4_xx = () => {
  const { changeMenuFilter } = useMenuContext_xx();
  return (
    <div className='btn-container'>
      <h1>FilterButtons4_xx</h1>
    </div>
  );
};
export default FilterButtons4_xx;
