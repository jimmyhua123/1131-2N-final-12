const MenuItem4_xx = () => {
  return (
    <article key={id} className='menu-item'>
      <h1>MenuItem4_xx</h1>
    </article>
  );
};

export default MenuItem4_xx;
