import Form_xx from '../components/Form_xx'
import Items_xx from '../components/Items_xx'

const GroceryPage_xx = () => {
  return (
    <section className='section-center'>
      <Form_xx />
      <Items_xx />
    </section>
  )
}

export default GroceryPage_xx
