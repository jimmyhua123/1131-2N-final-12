import GroceryPage_xx from './pages/GroceryPage_xx'

const App_xx = () => {
  return (
    <>
      <GroceryPage_xx />
    </>
  )
}

export default App_xx
