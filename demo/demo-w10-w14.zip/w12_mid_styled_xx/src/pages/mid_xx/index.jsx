export { default as P1Page_xx } from './P1Page_xx'
export { default as P2Page_xx } from './P2Page_xx'
export { default as P3Page_xx } from './P3Page_xx'
export { default as P4Page_xx } from './P4Page_xx'
