import T37_xx from './tutorial/03-conditional-rendering/T37-user-challenge_xx'

function App() {
  return (
    <div className='container'>
      <h4>Tutorial T37_xx</h4>
      <h5>Hsingtai Chung, 123456789</h5>
      <T37_xx />
    </div>
  )
}

export default App
