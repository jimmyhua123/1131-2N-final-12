import T21_xx from './tutorial/02-useEffect/T21-code-example_xx'

function App() {
  return (
    <div className='container'>
      <h4>Tutorial T21_xx</h4>
      <h5>Hsingtai Chung, 123456789</h5>
      <T21_xx />
    </div>
  )
}

export default App
