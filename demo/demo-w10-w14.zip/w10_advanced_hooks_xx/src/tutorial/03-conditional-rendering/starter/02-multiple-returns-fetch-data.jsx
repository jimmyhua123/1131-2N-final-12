import { useEffect, useState } from 'react';
const url = 'https://api.github.com/users/QuincyLarson';

const MultipleReturnsFetchData = () => {
  return <h2>Fetch Data </h2>;
};
export default MultipleReturnsFetchData;
