import T92_xx from './tutorial/09-context-api/T92_xx-context-api'

function App() {
  return (
    <div className='container'>
      <h4>Tutorial T92_xx</h4>
      <h5>Hsingtai Chung, 123456789</h5>
      <T92_xx />
    </div>
  )
}

export default App
